package com.izaac.api_exemplo.api_transito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTransitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTransitoApplication.class, args);
	}

}
