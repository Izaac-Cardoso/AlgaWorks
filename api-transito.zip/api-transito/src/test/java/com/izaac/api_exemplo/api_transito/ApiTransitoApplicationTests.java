package com.izaac.api_exemplo.api_transito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTransitoApplicationTests {

	@Test
	void contextLoads() {
	}

}
